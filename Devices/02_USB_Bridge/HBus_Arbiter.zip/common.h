//****************************************************************************** 
// Project:     HBus Arbiter
// Author:      A.Kouznetsov
// Rev:         1.0
// Date:        5/11/2018
// Target:      PIC16F18323
// File:        common.c
//****************************************************************************** 


#ifndef COMMON_H
#define	COMMON_H

#ifdef	__cplusplus
extern "C" {
#endif


//##############################################################################
// Typedef
//##############################################################################

#ifndef __UCHAR_DEFINED__
  #define __UCHAR_DEFINED__
  typedef unsigned char uchar;
  typedef signed   char schar;
  typedef unsigned int  uint;
  typedef unsigned long ulong;
  typedef signed   long slong;
#endif

    
//##############################################################################
// Func
//##############################################################################
    
void TMR0_isr(void);
void IOCCF1_isr(void);
void IOCCF4_isr(void);

#ifdef	__cplusplus
}
#endif

#endif	/* COMMON_H */

