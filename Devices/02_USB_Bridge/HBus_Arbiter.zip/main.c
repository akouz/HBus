//****************************************************************************** 
// Project:     HBus Arbiter
// Author:      A.Kouznetsov
// Rev:         1.0
// Date:        5/11/2018
// Target:      PIC16F18323
// File:        main.c
//****************************************************************************** 


//##############################################################################
// Inc
//##############################################################################

#include "mcc_generated_files/mcc.h"
#include "common.h"

//##############################################################################
// Def
//##############################################################################

#define _TP0        LATA0
#define _TP1        LATA1
#define _ERR        LATA4
#define _RS485      RA5

#define _RX         RC1
#define _TX_DIS     LATC2
#define _TX         RC4


enum{
    ST_IDLE     = 0,    
    ST_RX       = 1,    // cannot transmit
    ST_TX       = 2,
};

//##############################################################################
// Var
//##############################################################################

uchar state;

//##############################################################################
// Func
//##############################################################################

// ======================================
// Reload timer
// ======================================
void reload_TMR0(void)
{
    TMR0H = 0xFB;       // reload 600 us time-out
    TMR0L = 0x50;
    PIR0bits.TMR0IF = 0;
    T0CON0bits.T0EN = 1;
    _ERR = 1;           // report to PC: Tx disabled
}

// ======================================
// Main 
// ======================================
void main(void)
{
    SYSTEM_Initialize();
    state = ST_IDLE;
    TMR0_StopTimer();
    PIE0bits.IOCIE = 1;
    PIE0bits.TMR0IE = 0;    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();    
    while (1)
    {
        _TP1 = ~_TP1;  // debug
        // --------------------------
        // Idle state - waiting for either Tx or Rx
        // --------------------------
        if (state == ST_IDLE)
        {  
            switch (PORTC & 0x12) // select RC4 and RC1
            {
                case 0: // both _RX and _TX active - assume transmission
                case 2: // _TX active, _RX passive - transmission
                    _TP0 = 0;
                    _TX_DIS = 0;
                    IOCCFbits.IOCCF4 = 0;   // clear interrupt flag
                    state = ST_TX;
                    break;
                case 0x10: // _RX active, _TX passive    
                    _TX_DIS = 1;            // disable Tx
                    reload_TMR0(); 
                    state = ST_RX;
                    break;
                default: // both passive
                    _TP0 = 1;
                    _TX_DIS = 0;
                    _ERR = 0;
                    PIE0bits.IOCIE = 1;  // ensure
                    break;
            }        
        }       
        // --------------------------
        // Rx state - Tx disabled, waiting for long pause
        // --------------------------
        else if (state == ST_RX)
        {
            if (_RX == 0)
            {
                reload_TMR0();          // reset time-out
            }
            else if (PIR0bits.TMR0IF == 1) // 600 us since last Rx=low
            {
                _TX_DIS = 0;            // enable Tx
                _ERR = 0;               // report to PC: it is OK to Tx
                T0CON0bits.T0EN = 0;            
                state = ST_IDLE;                
            }                    
        }    
        // --------------------------
        // Tx state 
        // --------------------------
        else
        {
           _TX_DIS = 0;
           _ERR = 0;
           PIE0bits.IOCIE = 1;
        }    
    }
}
// ======================================
// Tx pin - interrupt on rising edge
// ======================================
void IOCCF4_isr(void)
{
    IOCCFbits.IOCCF4 = 0;
    if (state == ST_TX)
    {    
        _TP0 = 1;
        if (_RX == 0) // if collision
        {
            _TX_DIS = 1;    // disable Tx
            reload_TMR0();  // and report to PC
            state = ST_RX;
        }    
        else // OK, no collision
        {
            _TX_DIS = 0;    // ensure Tx enabled
            state = ST_IDLE;
        }
    }
    else if (state == ST_RX)
    {    
        reload_TMR0();  // stay in Rx state while PC transmits
    }
}

/* EOF */