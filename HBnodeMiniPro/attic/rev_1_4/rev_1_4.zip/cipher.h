// Cipher codes for HBcipher
// Default cipher 
enum{
  KEY1   = 0x60F3C66D,
  KEY2   = 0x5DF53900,
  KEY3   = 0x4F533EB6,
  KEY4   = 0xE42B2A61,
  ROUNDS = 6,
  LFSR1  = 0x1EDC6F41,
  LFSR2  = 0x04C11DB7,
  LFSR16 = 0x755B
};
